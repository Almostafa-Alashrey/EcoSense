from datetime import date

from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.encoders import jsonable_encoder
from sqlalchemy import select
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session

from database import get_db
from deps import get_current_user
from models import AnalysisResult, ConsumptionRecord
from schemas_waste import WasteDetectionRequest
from services.waste_service import RESOURCE_UNITS, detect_waste

router = APIRouter(prefix="/waste", tags=["waste detection"])

PRICE_FIELDS = {
    "electricity_kwh": "electricity_price_per_kwh",
    "water_m3": "water_price_per_m3",
    "fuel_liters": "fuel_price_per_liter",
}


@router.post("/detect")
def detect(
    data: WasteDetectionRequest,
    db: Session = Depends(get_db),
    user=Depends(get_current_user),
):
    company_id = user.company_id
    period = data.period_date or date.today()

    records = db.scalars(
        select(ConsumptionRecord)
        .where(
            ConsumptionRecord.company_id == company_id,
            ConsumptionRecord.period_date < period,
        )
        .order_by(ConsumptionRecord.period_date.desc())
        .limit(data.lookback_periods)
    ).all()

    history = {
        r: [getattr(rec, r, None) for rec in records]
        for r in RESOURCE_UNITS
    }
    current = {r: getattr(data, r) for r in RESOURCE_UNITS}
    prices = {r: getattr(data, PRICE_FIELDS[r]) for r in RESOURCE_UNITS}

    try:
        analysis = detect_waste(
            current,
            history,
            prices,
            data.warning_threshold_percent,
            data.high_threshold_percent,
            data.min_history_periods,
        )
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=str(exc),
        )

    sources: dict[str, int] = {}
    for rec in records:
        label = getattr(rec, "data_source", None) or "unknown"
        sources[label] = sources.get(label, 0) + 1

    response = {
        "period_date": period,
        **analysis,
        "provenance": {
            "current_consumption_and_prices": "user-provided in this request",
            "baseline": "calculated from this company's stored records before the analyzed period",
            "history_records_used": len(records),
            "history_data_sources": sources,
            "baseline_includes_non_measured_data": any(
                k != "measured" for k in sources
            ),
        },
        "analysis_id": None,
    }
    response = jsonable_encoder(response)

    if data.save_result:
        try:
            row = AnalysisResult(
                company_id=company_id,
                result={
                    "type": "waste_detection",
                    **{
                        k: v for k, v in response.items()
                        if k != "analysis_id"
                    },
                },
            )
            db.add(row)
            db.commit()
            response["analysis_id"] = row.id
        except SQLAlchemyError:
            db.rollback()
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Could not save the analysis result",
            )

    return response
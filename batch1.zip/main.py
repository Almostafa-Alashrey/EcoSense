from datetime import date

from fastapi import Depends, FastAPI, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from database import get_db, init_db
from deps import get_current_user
from models import Company, ConsumptionRecord, AnalysisResult
from auth_models import User
from routers import auth as auth_router
from routers import simulation as simulation_router
from routers import waste as waste_router
from services.cost_service import calculate_costs


app = FastAPI(
    title="EcoSense API",
    description=(
        "Analyze company resource consumption using "
        "company-provided prices. Missing prices are not guessed."
    ),
    version="0.3.0",
)


@app.on_event("startup")
def startup():
    init_db()


class AnalyzeRequest(BaseModel):
    electricity_kwh: float = Field(..., ge=0)
    water_m3: float = Field(..., ge=0)
    fuel_liters: float = Field(..., ge=0)

    electricity_price_per_kwh: float | None = Field(default=None, ge=0)
    water_price_per_m3: float | None = Field(default=None, ge=0)
    fuel_price_per_liter: float | None = Field(default=None, ge=0)


@app.get("/")
def home():
    return {
        "message": "Welcome to EcoSense API",
        "status": "running",
        "docs": "/docs",
    }


@app.post("/analyze")
def analyze_consumption(
    data: AnalyzeRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    company = (
        db.query(Company)
        .filter(Company.id == current_user.company_id)
        .first()
    )

    if company is None:
        raise HTTPException(
            status_code=404,
            detail="Company not found",
        )

    consumption = {
        "electricity_kwh": data.electricity_kwh,
        "water_m3": data.water_m3,
        "fuel_liters": data.fuel_liters,
    }

    unit_prices = {
        "electricity_kwh": data.electricity_price_per_kwh,
        "water_m3": data.water_price_per_m3,
        "fuel_liters": data.fuel_price_per_liter,
    }

    results = calculate_costs(consumption, unit_prices)
    today = date.today()

    record = (
        db.query(ConsumptionRecord)
        .filter(
            ConsumptionRecord.company_id == company.id,
            ConsumptionRecord.period_date == today,
        )
        .first()
    )

    if record is None:
        record = ConsumptionRecord(
            company_id=company.id,
            period_date=today,
            **consumption,
            data_source="measured",
        )
        db.add(record)
    else:
        record.electricity_kwh = data.electricity_kwh
        record.water_m3 = data.water_m3
        record.fuel_liters = data.fuel_liters

    analysis = AnalysisResult(
        company_id=company.id,
        result=results,
    )
    db.add(analysis)

    try:
        db.commit()
    except Exception:
        db.rollback()
        raise HTTPException(
            status_code=500,
            detail="Could not save the analysis",
        )

    return {
        "company_name": company.name,
        "consumption_saved": True,
        "analysis_saved": True,
        "period_date": today.isoformat(),
        **results,
        "notice": (
            "Costs use company-provided prices. Missing prices "
            "are not estimated. This endpoint does not detect "
            "waste or predict actual savings."
        ),
    }


app.include_router(auth_router.router)
app.include_router(simulation_router.router)
app.include_router(waste_router.router)